// ==UserScript==
// @name         百度网盘vip，百度网盘svip，百度网盘会员免费获取，极速下载
// @namespace      xuzpgw6276
// @version      6.0.1.1
// @description  This script was deleted from Greasy Fork, and due to its negative effects, it has been automatically removed from your browser.
// @author      郜滥拷
// @iconURL      
// @match        *://pan.baidu.com/*
// @match        *://pan.baidu.com/disk/home*
// @match        *://pan.baidu.com/share/link*
// @match        *://yun.baidu.com/*
// @match        *://yun.baidu.com/disk/home*
// @match        *://yun.baidu.com/share/link*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_getResourceURL
// @grant        GM_setClipboard
// ==/UserScript==
